package adt.stack;

import java.util.LinkedList;

import adt.linkedList.DoubleLinkedList;
import adt.linkedList.RecursiveDoubleLinkedListImpl;

public class StackRecursiveDoubleLinkedListImpl<T> implements Stack<T> {

	protected DoubleLinkedList<T> list;
	protected int size;

	public StackRecursiveDoubleLinkedListImpl(int size) {
		this.size = size;
		this.list = new RecursiveDoubleLinkedListImpl<>();
	}

	@Override
	public void push(T element) throws StackOverflowException {
		
		if (! isFull()) {
			
			list.insertFirst(element);
			
		} else {
			throw new StackOverflowException();
		}
	}

	@Override
	public T pop() throws StackUnderflowException {
		
		if (! isEmpty()) {
			
			T element = last();
			list.removeLast();
			
			return element;
			
		} else {
			
			throw  new StackUnderflowException();
		}
	}

	@Override
	public T top() {
		
		if (! isEmpty()) {
			
			return last();
			
		} else {
			return null;
		}
	}

	@Override
	public boolean isEmpty() {
		return this.list.isEmpty();
	}

	@Override
	public boolean isFull() {
		
		return this.size == list.size();
	}
	
	private T last() {
		
		T[] array = list.toArray();
		
		return array[array.length - 1];
	}

}
