package adt.linkedList;

public class RecursiveDoubleLinkedListImpl<T> extends
RecursiveSingleLinkedListImpl<T> implements DoubleLinkedList<T> {

	protected RecursiveDoubleLinkedListImpl<T> previous;

	public RecursiveDoubleLinkedListImpl() {

	}

	public RecursiveDoubleLinkedListImpl(T data,
			RecursiveSingleLinkedListImpl<T> next,
			RecursiveDoubleLinkedListImpl<T> previous) {
		super(data, next);
		this.previous = previous;
	}

	@Override
	public void insertFirst(T element) {

		RecursiveDoubleLinkedListImpl<T> newNode = new RecursiveDoubleLinkedListImpl<>(element, getNext(), this);

		setNext(newNode);
		swap(newNode, this);
	}

	@Override
	public void insert(T element) {

		if (isEmpty()) {

			insertFirst(element);

		} else if (getNext().isEmpty()) {

			RecursiveDoubleLinkedListImpl<T> no = (RecursiveDoubleLinkedListImpl<T>) getNext();
			no.setData(element);
			no.setPrevious(this);
			no.setNext(new RecursiveDoubleLinkedListImpl<T>());

		} else {

			getNext().insert(element);
		}
	}

	@Override
	public void removeFirst() {

		if (! isEmpty()) {
			RecursiveDoubleLinkedListImpl<T> nextNode = (RecursiveDoubleLinkedListImpl<T>) getNext();
			nextNode.setPrevious(null);

			shift();
		}
	}

	@Override
	public void remove(T element) {

		if (! isEmpty()) {


			if (isHead() && getData() == null && element == null) {

				removeFirst();

			} else if (isHead() && getData() == null && element != null) {

				getNext().remove(element);

			} else if (isHead() && getData().equals(element)) {
				removeFirst();

			} else if (! isLast() && getData() == null && element == null) {

				getPrevious().setNext(getNext());

				RecursiveDoubleLinkedListImpl<T> next = (RecursiveDoubleLinkedListImpl<T>) getNext();
				next.setPrevious(getPrevious());

			} else if (! isLast() && getData() == null && element != null) {


				getNext().remove(element);

			} else if (! isLast() && getData().equals(element)) {


				getPrevious().setNext(getNext());

				RecursiveDoubleLinkedListImpl<T> next = (RecursiveDoubleLinkedListImpl<T>) getNext();
				next.setPrevious(getPrevious());
			
			} else if (! isLast() && ! getData().equals(element)) {
				getNext().remove(element);

			} else if (isLast() && getData() == null && element == null) {

				removeLast();

			} else if (isLast() && getData() == null && element != null) {

				getNext().remove(element);

			} else if (isLast() && getData().equals(element)) {

				removeLast();
			}
		}
	}

	@Override
	public void removeLast() {

		if (! isEmpty()) {

			if (isLast()) {

				if (isHead()) {
					removeFirst();

				} else {

					getPrevious().setNext(new RecursiveDoubleLinkedListImpl<T>());
				}

			} else {

				RecursiveDoubleLinkedListImpl<T> nextNode = (RecursiveDoubleLinkedListImpl<T>) getNext();

				nextNode.removeLast();
			}
		}
	}

	public RecursiveDoubleLinkedListImpl<T> getPrevious() {
		return previous;
	}

	public void setPrevious(RecursiveDoubleLinkedListImpl<T> previous) {
		this.previous = previous;
	}

	private void swap(RecursiveDoubleLinkedListImpl<T> a, RecursiveDoubleLinkedListImpl<T> b) {

		T aux = a.getData();
		a.setData(b.getData());
		b.setData(aux);
	}

	private boolean isHead() {

		return getPrevious() == null;
	}

	private boolean isLast() {

		return getNext().isEmpty();
	}

}
