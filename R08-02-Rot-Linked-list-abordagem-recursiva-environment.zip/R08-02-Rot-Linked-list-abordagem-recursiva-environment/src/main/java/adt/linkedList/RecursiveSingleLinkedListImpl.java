package adt.linkedList;

public class RecursiveSingleLinkedListImpl<T> implements LinkedList<T> {

	protected T data;
	protected RecursiveSingleLinkedListImpl<T> next;

	public RecursiveSingleLinkedListImpl() {

	}

	public RecursiveSingleLinkedListImpl(T data,
			RecursiveSingleLinkedListImpl<T> next) {
		this.data = data;
		this.next = next;
	}

	@Override
	public boolean isEmpty() {

		if (getData() == null && getNext() == null) {

			return true;
		} else {
			return false;
		}
	}

	@Override
	public int size() {

		int size = 1;

		if(isEmpty()) {
			return 0;

		} else if (! getNext().isEmpty()){

			size += getNext().size();
			
		}

		return size;
	}

	@Override
	public T search(T element) {
		
		if (element == null) {
			return null;
		}

		if (isEmpty()) {
			return null;
		
		} else if (getData() == null && getNext() == null) {
			return null;
			
		} else if (getData() == null && getNext() != null) {
			return getNext().search(element);
	
		} else if (getData().equals(element)) {
			return getData();

		} else if (! getData().equals(element) && getNext() != null){
			return getNext().search(element);
		} else {
			return null;
		}
	}

	@Override
	public void insert(T element) {

		if (isEmpty()) {
			setData(element);
			setNext(new RecursiveSingleLinkedListImpl<T>());
		
		} else if (! getNext().isEmpty()){

			getNext().insert(element);
			
		} else {
			
			RecursiveSingleLinkedListImpl<T> newNode = new RecursiveSingleLinkedListImpl<>(element, new RecursiveSingleLinkedListImpl<T>());
			
			setNext(newNode);
		}
	}

	@Override
	public void remove(T element) {

		if (! isEmpty()) {
			
			if (getData() == null && element == null) {
				shift();
			} else if (getData() == null && element != null) {
				getNext().remove(element);
				
			} else if (getData().equals(element)){
				shift();	
				
			} else {
				getNext().remove(element);
			}
		}
	}

	protected void shift() {

		if (! getNext().isEmpty()) {

			setData(getNext().getData());
			getNext().shift();

		} else {

			setData(null);
			setNext(null);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public T[] toArray() {
		
		if (isEmpty()) {
			
			T[] array = (T[]) new Object[]{};
			
			return array;
			
		} else {
			
			T[] array = (T[]) new Object[size()];
			adicionaArray(array, 0);
			
			return array;
		}
	}
	
	private void adicionaArray(T[] array, int pos) {
		
		if (! isEmpty()) {
			
			array[pos] = getData();
			getNext().adicionaArray(array, pos + 1);
		}
	}

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}

	public RecursiveSingleLinkedListImpl<T> getNext() {
		return next;
	}

	public void setNext(RecursiveSingleLinkedListImpl<T> next) {
		this.next = next;
	}
}
